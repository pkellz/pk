 $(function(){
   $nav_ul = $('.nav-ul')
   $(window).on('scroll',function(){
     if($(this).scrollTop()){
       $nav_ul.addClass('dark')
     }
     else {
       $nav_ul.removeClass('dark')
     }
   })
 })
